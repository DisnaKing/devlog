# Llenguatges més utilitzats

| Llenguatge | Nivell d'abstracció | Propósit | Compilat o interpretat | Paradigma o paradigmes|
|:-|:-|:-|:-|:-|
| Python |Alt nivell | General | Interpretat | Estructurada|
| C++ | Alt nivell | General | Compilat | POO | 
| Java |Alt nivell | General | Compilat e interpretat | POO
| C | Nivell intermedi | General | Compilat | Estructurada y modular
| C# | alt nivell | General | Compilat | POO |