# Exemples Python, Java i C
[Ejemplos con más lenguajes](https://medium.com/streamelopers/hello-world-en-10-lenguajes-a30f73d771c4)
## Python

```bash
print ("Hola Món!")
```

## Java

```bash
public class Hola {
    public static void main(String[] args) {
        System.out.println("Hola Món!");
    }
}
```

## C

```bash
#include <stdio.h>
int main() {
   printf("Hello World!\n");
   return 0;
}
```
