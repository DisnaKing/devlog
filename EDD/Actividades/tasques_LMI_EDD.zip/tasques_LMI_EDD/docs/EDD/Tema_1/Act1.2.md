# Desenvolupament App

Utilitzaria **Kotlin Multiplatform**

## Pasos a seguir

1. Tindre clar el que volem fer, la part del client i la del servidor
2. Disseñar-ho
3. Dessarollar l'aplicació, la part client amb **Kotlin Multiplatform** i la part del servidor amb **PHP**