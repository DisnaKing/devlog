# L'efecte bola de neu
![alt text](download.jpg)

## Canvi de model de desenvolupament

- Utilitzar un model àgil o Scrum
- Ajustar les especificacions durant el procés

## Interacció constant amb el client

- Reunions periòdiques amb el client
- Implementar prototips en les primeres etapes per validar amb el client
  
## Gestió de requsits flexible

- A mesura que el projecte avança es important que hi hagi mecanismes per gestionar els canvis de requisits

## Foment de la col·laboració entre equips

- Involucrar el client com a part de l'equip
