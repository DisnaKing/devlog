# Conflicte d'interesos
- S'ha sobrecarregat els equips amb treball
- La comunicació hauria d'haver sigut millor
- El Product Owner havia creat expectatives inadecuades amb el client
- No s'han prioritzat de forma correcta les tasques a realitzar